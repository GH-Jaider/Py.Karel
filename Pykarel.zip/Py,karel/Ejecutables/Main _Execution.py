import pygame, sys, os
import colorsandtext as c
from pygame import *
import funciones as f
from funciones import boton
import lecturamapas as m
# ======================================================================================================================
pygame.init()

# ======================================================================================================================
# parametros predefinidos
# tablero = Board.Board() #nombrar metodo para usarlo con facilidad
myFont = font.Font(None, 35)  # importar fuente para titulos
myFont2 = font.Font(None, 20)  # importar fuente texto pequeño
myFont3 = font.Font(None, 24)  # importar fuente texto medio

# =====================================================================================================================
# variables de inicio
size = (700, 700) #tamaño de la ventana
screen = pygame.display.set_mode(size) #variable para ventana
clock = pygame.time.Clock()  # para controlar fps en animaciones
tex1 = myFont3.render("60 char", True, c.white)

# ======================================================================================================================
# Botones

botonInicio = Rect(300, 420, 100, 40)  # rectangulo para el boton de Inicio
botonInicio_pressed = None #booleano para usar el boton

# Boton de instrucciones

botonHelp = Rect(640, 640, 40, 40) # rectangulo para el boton de help
botonHelp_pressed = None #booleano para usar el boton

botonBack = Rect(20, 20, 40, 40)  # para el boton back
boton_pressed = None #bool correspondiente

botonNext = Rect(450, 640, 40, 40)  # para el boton next
botonNext_pressed = False

botonReverse = Rect(160, 640, 40, 40) #para el boton reverse
botonReverse_pressed = None #bool correspondiente

botonNext2 = Rect(490, 640, 40, 40) #para el boton next2
botonNext2_pressed = False #bool correspondiente

botonReverse2 = Rect(110, 640, 40, 40) #para el boton reverse2
botonReverse2_pressed = False #bool correspondiente


botoni = Rect(640, 380, 30, 30) #para visualizar la forma de insterpretar el mapa en instrucciones

count = None #bool para ejecutar el interpretador
executed = None
# ======================================================================================================================
# inicio de la ejecucion
#=======================================================================================================================

while True:
    for event in pygame.event.get():  #para poder ceerrar la ventana de pygame
        if event.type == pygame.QUIT:
            sys.exit()

    screen.fill(c.blueblack)  # color del fondo

    # Pantalla de inicio

    boton(screen, myFont, botonInicio, "Iniciar", c.purple)  # boton de instrucciones
    boton(screen, myFont, botonHelp, "?", c.blueclear)  # boton help
    screen.blit(f.picture, [235, 70])  #imagen del logo
    f.creditos(screen, myFont2) #creditos de los creadores


    if event.type == MOUSEBUTTONDOWN:
        if botonHelp.collidepoint(mouse.get_pos()):
            botonHelp_pressed = True  #hace que al clicar help el bool se active para que la pantalla se actualice
    # ======================================================================================================================
    # Muestra de las instrucciones si se clica el boton de help
    if botonHelp_pressed == True:
        screen.fill(c.blueblack)  # color del fondo
        f.titulos(screen, myFont, Rect(20, 80, 200, 40), "Instrucciones", c.blueblack) #titulo
        f.texter(screen, c.tex1, myFont3, 20, 140) #texto
        f.texter(screen, c.tex2, myFont3, 20, 192) #texto
        f.texter(screen, c.tex6, myFont3, 20, 560) #texto
        f.texter(screen, c.tex7, myFont3, 20, 600) #texto
        pygame.draw.line(screen, c.white, [450, 606], [470, 606]) #para hacer evidente como interactuar con las instrucciones
        pygame.draw.line(screen, c.white, [470, 606], [470, 650])


        # para mostrar la siguiente pagina de instrucciones
        boton(screen, myFont, botonNext, "»", c.blueclear)  # Boton para pasar de pagina
        if event.type == MOUSEBUTTONDOWN:
            if botonNext.collidepoint(mouse.get_pos()):
                botonNext_pressed = True

        # se muestra la siguiente pagina de instrucciones
        if botonNext_pressed:
            screen.fill(c.blueblack)  # color del fondo
            f.texter(screen, c.tex4, myFont3, 20, 100) #items listados de instrucciones
            screen.blit(f.picture1, [200, 290]) #imagen de ayuda visual
            f.texter(screen, c.tex5, myFont3, 20, 560) #texto al final de la pagina

        #boton para pasar de pagina
            boton(screen, myFont, botonNext2, "»", c.blueclear)  # Boton para pasar de pagina
            if event.type == MOUSEBUTTONDOWN:
                if botonNext2.collidepoint(mouse.get_pos()):
                    botonNext2_pressed = True

            boton(screen, myFont, botonReverse, "«", c.blueclear)  # para ir a la pagina de instrcciones anterior
            if event.type == MOUSEBUTTONDOWN:
                if botonReverse.collidepoint(mouse.get_pos()):
                    botonReverse_pressed = True

            #hace que vuelvas a la pagina anterior cambiando los booleanos
            if botonReverse_pressed == True:
                botonNext_pressed = False
                botonReverse_pressed = False

            #muestra la siguiente pagina de instruccioens
            if botonNext2_pressed == True:
                screen.fill(c.blueblack) #color de fondo
                f.texter(screen, c.tex8, myFont3, 20, 100)
                f.texter(screen, c.tex9, myFont3, 20, 124)
                screen.blit(f.picture2, [350, 280]) #muestra las imagenes de mapa
                f.texter(screen, c.tex10, myFont3, 20, 560)
                screen.blit(f.picture4, [100, 280])

                #boton para hacer visible como interpretar los mapas
                boton(screen, myFont, botoni, "+", c.redsoft)  # Boton para salir de las instrucciones
                if event.type == MOUSEBUTTONDOWN:
                    if botoni.collidepoint(mouse.get_pos()):
                        screen.blit(f.picture3, [350, 280])

                #boton para ir a la pagina anterior
                boton(screen, myFont, botonReverse2, "«", c.blueclear)
                if event.type == MOUSEBUTTONDOWN:
                    if botonReverse2.collidepoint(mouse.get_pos()):
                        botonReverse2_pressed = True

                if botonReverse2_pressed == True:
                    botonNext2_pressed = False
                    botonReverse2_pressed = False


        #boton back para volver al inicio
        boton(screen, myFont, botonBack, "«", c.redsoft)  # Boton para salir de las instrucciones
        if event.type == MOUSEBUTTONDOWN:
            if botonBack.collidepoint(mouse.get_pos()):
                botonHelp_pressed = False
                botonNext_pressed = False
                botonNext2_pressed = False

# ====================================================================================================================
    if event.type == MOUSEBUTTONDOWN:
        if botonInicio.collidepoint(mouse.get_pos()):  ## para iniciar
            botonInicio_pressed = True

    if botonInicio_pressed == True:

        os.system("python ejecucionview.py")  #ejecuta el interpretador de fondo y muestra su ejecucion en pantalla
        count = True #variable para que no se repita la ejecucion por el ciclo while
        if count == True:
            botonInicio_pressed = False
            count = False
            executed = True
    if executed == True:
        if len(m.Error) == 0: #si la ejecucion fue correcta se le muestra al ususario un mensaje
            screen.fill(c.blueblack)  # color de fondo
            f.texter(screen,"Karel ha completado su ejecución de manera correcta ;]", myFont3, 140, 150)
            screen.blit(f.picture5, [100, 260])  # muestra la imagen de ejecucion terminada
            boton(screen, myFont, botonBack, "«", c.redsoft)  # Boton para volver al menu
            if event.type == MOUSEBUTTONDOWN:
                if botonBack.collidepoint(mouse.get_pos()):
                    botonInicio_pressed = False
                    executed = False
        else: #si el codigo tuvo errores se muestra una pantalla donde se le sugiere revisar el codigo
            screen.fill(c.blueblack)  # color de fondo
            f.texter(screen, "Algo salió mal :[  Revisa las instrucciones de Karel", myFont3, 150, 150)
            screen.blit(f.picture6, [100, 280])  # muestra la imagen de ejecucion erronea
            boton(screen, myFont, botonBack, "«", c.redsoft)  # Boton para volver al menu
            if event.type == MOUSEBUTTONDOWN:
                if botonBack.collidepoint(mouse.get_pos()):
                    botonInicio_pressed = False
                    executed = False


    pygame.display.flip()