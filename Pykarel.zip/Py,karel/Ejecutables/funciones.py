import pygame, lecturamapas
from pygame import *
import colorsandtext as c

#======================================================================================================================
# Imagenes de la interfaz
#======================================================================================================================
logo = pygame.image.load("image0.png")  #Logo py.karel
picture = pygame.transform.rotozoom(logo, 0, 0.3)

image1 = pygame.image.load("image1.png") #Imagen para las instrucciones
picture1 = pygame.transform.rotozoom(image1, 0, 0.12)

image2 = pygame.image.load("image2.png") #Imagen para las instrucciones de mapa
picture2 = pygame.transform.rotozoom(image2, 0, 0.1347)

image3 = pygame.image.load("image3.png") # imagen para instruccioens mapa
picture3 = pygame.transform.rotozoom(image3, 0, 0.13)

image4 = pygame.image.load("image4.png") #imagen para instrucciones de mapa
picture4 = pygame.transform.rotozoom(image4, 0, 0.65)

image5 = pygame.image.load("image5.png")
picture5 = pygame.transform.rotozoom(image5,0, 2)

image6 = pygame.image.load("image6.png")
picture6 = pygame.transform.rotozoom(image6, 0, 2)
#=======================================================================================================================
#Funciones
#=======================================================================================================================

#funcion para crear botones a partir de un rectangulo

def boton(screen,myFont, boton, palabra, color): #Recibe la pantalla, la fuente, un ractangulo, una str y un color
    if boton.collidepoint(mouse.get_pos()):
        draw.rect(screen, (color[0]-20, color[1]-40, color[2]-40), boton, 0) #hace que al pasar el mouse el rectangulo cambie de color
    else: #dibuja el cuadrado con los parametros inciales
        draw.rect(screen, color, boton, 0)
    texto = myFont.render(palabra, True, (255, 255, 255))
    screen.blit(texto, ((boton.x+(boton.width-texto.get_width())/2),
                                boton.y+(boton.height - texto.get_height())/2))


#Funcion para crear titulos a partir de un rectangulo en pantalla
def titulos(screen,myFont, cuadro, palabra, color, center = False):
    draw.rect(screen, color, cuadro, 0)
    texto = myFont.render(palabra, True, (255, 255, 255))
    if center == False:
        screen.blit(texto, (cuadro.x,cuadro.y))
    else:
        screen.blit(texto, ((cuadro.x + (cuadro.width - texto.get_width()) / 2), #centra el texto
                            cuadro.y + (cuadro.height - texto.get_height()) / 2))


#Funcion para crear texto de tamaño medio a partir de un rectangulo
def texto(screen,myFont3, cuadro, palabra, color):
    draw.rect(screen, color, cuadro, 0)
    texto = myFont3.render(palabra, True, (255, 255, 255))
    screen.blit(texto, (screen.x, screen.y))
def textosmall(screen, myFont2, cuadro, palabra, color):
    draw.rect(screen, color, cuadro, 0)
    texto = myFont2.render(palabra, True, (255, 255, 255))
    screen.blit(texto, ((cuadro.x + (cuadro.width - texto.get_width()) / 2),
                        cuadro.y + (cuadro.height - texto.get_height()) / 2))

#Funcion que inserta los titulos de creacion en pantalla
def creditos(screen, myFont2):
    cred = ["Creado por:", "Jaider Duván Velasco Diaz", "Juan Andrés Alayón Ariza", "Wenceslao Huang" ]
    cuadros = [(Rect(250, 540, 200, 20)), (Rect(250, 570, 200, 20)), (Rect(250, 600, 200, 20)), (Rect(250, 630, 200, 20))]
    for i in range(4):
        textosmall(screen, myFont2, cuadros[i], cred[-i], c.blueblack)

#funcion para poder escribir parrafos de texto (ya que pygame solo permite lineas unicas)

def texte(tex, myFont3):  #(se usa en la funcion principal 'texter')
    list = []
    lis = []
    for i in tex:
        lis.append(i)
        if len(lis) == 81:
            list.append("".join(lis))
            lis = []
    list.append("".join(lis))
    textead = []
    for line in list:
        textead.append(myFont3.render(line, True, c.white))
    return textead

def texter(screen, tex, myFont3, x, y): #funcion que permite escribir parrafos
    for i in range(len(texte(tex, myFont3))):
        screen.blit(texte(tex, myFont3)[i], (x, y + i*25))


# =============================================================================
# squares.py define todos los cuadrados de la cuadricula en la lista llamada squares
# =============================================================================

def s_vertical(x):
    l = []
    for y in range(50,550,20):
        l.append((x,y,20,20)) # Forma una tupla y se agrega a l de la linea 7
    return l                # La tupla se define de (coordenada x, coordenada y, ancho, alto)

squares = []    # En esta lista se encuentra todos los cuadrados definidos

for x in range(50,550,20): # Itera cada x y envia el argumento a la funcion vertical()
    squares.append(s_vertical(x)) # Agrega a la lista squares el retorno de vertical()




# =============================================================================
# triangles.py dibuja a karel
# =============================================================================



# Cada funcion define los tres puntos de karel (triangulo) y retorna la variable que contiene una tupla
# La tupla contiene 3 tuplas ((x1, y1),(x2, y2),(x3, y3))

def north(x, y):
    n1 = (squares[x][y][0],squares[x][y][1]+18)
    n2 = (squares[x][y][0]+10,squares[x][y][1]+2)
    n3 = (squares[x][y][0]+20,squares[x][y][1]+18)
    north = (n1, n2, n3)
    return north

def south(x, y):
    s1 = (squares[x][y][0],squares[x][y][1]+2)
    s2 = (squares[x][y][0]+10,squares[x][y][1]+18)
    s3 = (squares[x][y][0]+20,squares[x][y][1]+2)
    south = (s1, s2, s3)
    return south

def east(x, y):
    e1 = (squares[x][y][0]+2,squares[x][y][1])
    e2 = (squares[x][y][0]+18,squares[x][y][1]+10)
    e3 = (squares[x][y][0]+2,squares[x][y][1]+20)
    east = (e1, e2, e3)
    return east

def west(x, y):
    w1 = (squares[x][y][0]+18,squares[x][y][1])
    w2 = (squares[x][y][0]+2,squares[x][y][1]+10)
    w3 = (squares[x][y][0]+18,squares[x][y][1]+20)
    west = (w1, w2, w3)
    return west


karel = []

"""
El for de la linea 42 entrega por cada i una lista [x, y, f] de la posicion de karel 
[coordenada x, coordenada y, hacia donde mira(0=norte, 1=sur, 2=este, 3=oeste)] 
Por cada if verifica hacia donde mira karel y llama a la funcion respectiva
entrengandole las coordenadas
"""

for i in lecturamapas.s_coordenadaKarel:
    if i[2] == 0:
        karel.append(north(i[0], i[1]))
    if i[2] == 1:
        karel.append(south(i[0], i[1]))
    if i[2] == 2:
        karel.append(east(i[0], i[1]))
    if i[2] == 3:
        karel.append(west(i[0], i[1]))

# =============================================================================
# define todos los puntos de la cuadricula y los guarda en la lista llamada dots
# los beepers tambien se van a definir a partir de estos putnos definidos
# =============================================================================

def d_vertical(x):
    l = []
    for i in range(50,550,20):
        l.append((x+10,i+10))   # Forma una tupla y se agrega a l de la linea 7.
    return l                    # La tupla se define de (coordenada x, coordenada y)

dots = []  # En esta lista se encuentra todos los puntos definidos

for x in range(50,550,20):  # Itera cada x y envia el argumento a la funcion vertical()
    dots.append(d_vertical(x))    # Agrega a la lista dots el retorno de vertical()

