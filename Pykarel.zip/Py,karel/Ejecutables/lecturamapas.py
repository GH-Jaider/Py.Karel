# =============================================================================
# funciones Lectura Mapa
# =============================================================================
def front_is_blocked():  # revisa si la condición front is blocked es verdadera o falsa
    if facing[0] == 0:
        x = coordenadaKarel[0]
        y = coordenadaKarel[1] - 1
        if y < 0 or y >= longitud_mapaY or [x, y] in coordenadas_muros:
            return True
        else:
            return False
    if facing[0] == 1:
        x = coordenadaKarel[0]
        y = coordenadaKarel[1] + 1
        if y < 0 or y >= longitud_mapaY or [x, y] in coordenadas_muros:
            return True
        else:
            return False
    if facing[0] == 2:
        x = coordenadaKarel[0] + 1
        y = coordenadaKarel[1]
        if x < 0 or x >= longitud_mapaX or [x, y] in coordenadas_muros:
            return True
        else:
            return False
    if facing[0] == 3:
        x = coordenadaKarel[0] - 1
        y = coordenadaKarel[1]
        if x < 0 or x >= longitud_mapaX or [x, y] in coordenadas_muros:
            return True
        else:
            return False


def right_is_blocked():  # revisa si la condición right is blocked es verdadera o falsa
    if facing[0] == 0:
        x = coordenadaKarel[0] + 1
        y = coordenadaKarel[1]
        if x < 0 or x >= longitud_mapaX or [x, y] in coordenadas_muros:
            return True
        else:
            return False
    if facing[0] == 1:
        x = coordenadaKarel[0] - 1
        y = coordenadaKarel[1]
        if x < 0 or x >= longitud_mapaX or [x, y] in coordenadas_muros:
            return True
        else:
            return False
    if facing[0] == 2:
        x = coordenadaKarel[0]
        y = coordenadaKarel[1] + 1
        if y < 0 or y >= longitud_mapaY or [x, y] in coordenadas_muros:
            return True
        else:
            return False
    if facing[0] == 3:
        x = coordenadaKarel[0]
        y = coordenadaKarel[1] - 1
        if y < 0 or y >= longitud_mapaY or [x, y] in coordenadas_muros:
            return True
        else:
            return False


def left_is_blocked():  # revisa si la condición izquierda is blocked es verdadera o falsa
    if facing[0] == 0:
        x = coordenadaKarel[0] - 1
        y = coordenadaKarel[1]
        if x < 0 or x >= longitud_mapaX or [x, y] in coordenadas_muros:
            return True
        else:
            return False
    if facing[0] == 1:
        x = coordenadaKarel[0] + 1
        y = coordenadaKarel[1]
        if x < 0 or x >= longitud_mapaX or [x, y] in coordenadas_muros:
            return True
        else:
            return False
    if facing[0] == 2:
        x = coordenadaKarel[0]
        y = coordenadaKarel[1] - 1
        if y < 0 or y >= longitud_mapaY or [x, y] in coordenadas_muros:
            return True
        else:
            return False
    if facing[0] == 3:
        x = coordenadaKarel[0]
        y = coordenadaKarel[1] + 1
        if y < 0 or y >= longitud_mapaY or [x, y] in coordenadas_muros:
            return True
        else:
            return False


def next_to_a_beeper():  # revisa si karel se encuentra sobre un beeper
    x = coordenadaKarel[0]
    y = coordenadaKarel[1]
    if [x, y] in coordenadas_beepers:
        return True
    return False


def move():  # Realiza el movimiento cuando se le llama
    if front_is_blocked():
        print("error")
        Error.append(1)
        return
    else:
        x = coordenadaKarel[0]
        y = coordenadaKarel[1]
        nuevalinea = ""
        if facing[0] == 0:
            if next_to_a_beeper():
                mapa_no_enter[y] = mapa_no_enter[y].replace("^", "*")
            else:
                mapa_no_enter[y] = mapa_no_enter[y].replace("^", ".")
            y -= 1
            for i in range(len(mapa_no_enter[y])):
                if i == x:
                    nuevalinea += "^"
                else:
                    nuevalinea += mapa_no_enter[y][i]
        elif facing[0] == 1:
            if next_to_a_beeper():
                mapa_no_enter[y] = mapa_no_enter[y].replace("v", "*")
            else:
                mapa_no_enter[y] = mapa_no_enter[y].replace("v", ".")
            y += 1
            for i in range(len(mapa_no_enter[y])):
                if i == x:
                    nuevalinea += "v"
                else:
                    nuevalinea += mapa_no_enter[y][i]
        elif facing[0] == 2:
            if next_to_a_beeper():
                mapa_no_enter[y] = mapa_no_enter[y].replace(">", "*")
            else:
                mapa_no_enter[y] = mapa_no_enter[y].replace(">", ".")
            x += 1
            for i in range(len(mapa_no_enter[y])):
                if i == x:
                    nuevalinea += ">"
                else:
                    nuevalinea += mapa_no_enter[y][i]
        elif facing[0] == 3:
            if next_to_a_beeper():
                mapa_no_enter[y] = mapa_no_enter[y].replace("<", "*")
            else:
                mapa_no_enter[y] = mapa_no_enter[y].replace("<", ".")
            x -= 1
            for i in range(len(mapa_no_enter[y])):
                if i == x:
                    nuevalinea += "<"
                else:
                    nuevalinea += mapa_no_enter[y][i]
        mapa_no_enter[y] = nuevalinea
        coordenadaKarel[0] = x
        coordenadaKarel[1] = y
        facin = facing[0]
        s_coordenadaKarel.append([x, y, facin])
        NewBeepr()
        # imprimirmapa()
        return


def turnleft():  # hace que karel gire a su izquierda cuando esta es llamada
    y = coordenadaKarel[1]
    if facing[0] == 0:
        mapa_no_enter[y] = mapa_no_enter[y].replace("^", "<")
        facing[0] = 3
    elif facing[0] == 1:
        mapa_no_enter[y] = mapa_no_enter[y].replace("v", ">")
        facing[0] = 2
    elif facing[0] == 2:
        mapa_no_enter[y] = mapa_no_enter[y].replace(">", "^")
        facing[0] = 0
    elif facing[0] == 3:
        mapa_no_enter[y] = mapa_no_enter[y].replace("<", "v")
        facing[0] = 1
    x = coordenadaKarel[0]
    y = coordenadaKarel[1]
    facin = facing[0]
    s_coordenadaKarel.append([x, y, facin])
    NewBeepr()
    # imprimirmapa()


def pickbeeper():  # hace que se le agregue la posición actual de karel a la lista de coordenas de beepers
    x = coordenadaKarel[0]
    y = coordenadaKarel[1]
    facin = facing[0]
    if [x, y] in coordenadas_beepers:
        coordenadas_beepers.remove([x, y])
        nbeepers[0] = nbeepers[0] + 1
        # imprimirmapa()
        s_coordenadaKarel.append([x, y, facin])
        NewBeepr()
    else:
        print("error")
        Error.append(1)


def putbeeper():  # retira la pocición donde se encuentra karel de la lista de beepers
    x = coordenadaKarel[0]
    y = coordenadaKarel[1]
    facin = facing[0]
    if nbeepers[0] > 0:
        coordenadas_beepers.append([x, y])
        nbeepers[0] = nbeepers[0] - 1
        # imprimirmapa()
        s_coordenadaKarel.append([x, y, facin])
        NewBeepr()
    else:
        print("error")
        Error.append(1)


# =============================================================================
# funciones Lectura Codigo
# =============================================================================
def escrituraCodigo():  # se encarga de leer el archivo donde se encuentra el codigo de karel y crea un diccionario con este
    codigot = "Test.txt"
    archivo = open(codigot, "r")
    codigo = archivo.readlines()
    code = {}
    for i in range(len(codigo)):
        a = codigo[i].replace("\n", "")
        code.update({i + 1: a})
    archivo.close()
    del codigo
    return code


def Ftab():  # para detectar las tabulaciones
    if code[linea[0]].count("\t") == tabs[0]:
        return True
    print("error")
    Error.append(1)


def lecturaCodigo(code):  # funcion principal, en con ella se lee el codigo segun la linea que se encuentre
    line = code[linea[0]]
    if tabs[0] == 0:
        notabs(line)
        return
    elif tabs[0] == 1:
        if new_instruction_check():
            new_instruction()
        else:
            boe(line)
        return
    elif len(BOE) == 1:
        if cond_if_check() != False:
            num = cond_if_check()
            condIf(num)
            return
        elif cond_while_check():
            num = cond_while_check()
            condWhile(num)
            return
        elif iterate_check():
            num = iterate_check()
            return iterate(num)
        return lectura_instrucciones(line)


def notabs(
        line: str):  # revisa cuando se supone que no hay ninguna tabulación en el codigo, osea la primera y ultima linea
    if line.count("\t") == tabs[0]:
        if linea[0] == 1 and line == no_tabs[0]:
            linea[0] = linea[0] + 1
            BOP.append(True)
            tabs[0] = tabs[0] + 1
        elif linea[0] == len(code) and line == no_tabs[1]:
            BOP.clear()
        else:
            Error.append(1)
            print("Error de codigo")
    else:
        Error.append(1)
        print("Error de codigo")
    return


def new_instruction_check():  # revisa cuando debe haber una tabulación, osea define new instruccion, BOE y EOE
    x = code[linea[0]].replace("\t", "")
    if x[:23] == one_tab[1][:23] and x[-3:] == one_tab[1][-3:] and Ftab():
        return True


def new_instruction():  # revisa si se crea una nueva instrucción, agrega a una lista los movimientos que se definan, y esa lista la agraga al diccionario instrucciones con la llave que se le defina como la nueva instruccion
    NI.append(1)
    lista = []
    contador = 0
    x = code[linea[0]].replace("\t", "")
    x = x[23:-3]
    linea[0] = linea[0] + 1
    line = code[linea[0]]

    if line.replace("\t", "") == "BEGIN" and Ftab():
        f = len(BEGIN)
        BEGIN.append(1)
        tabs[0] = tabs[0] + 1
        contador = 0

        while f < len(BEGIN):
            linea[0] = linea[0] + 1
            line = code[linea[0]]
            if End():
                instrucciones.update({x: lista})
                NI.clear()
                return
            elif not iterate_check():
                val = lectura_instrucciones(line)
                lista.append(val)
                contador += 1
            else:
                num = iterate_check()
                val = iterate(num)
                lista.append(val)


def boe(line: str):  # revisa cuando hay un boe o un eoe y vuelva la condición BOE true
    if line.count("\t") == tabs[0]:
        if line.replace("\t", "") == one_tab[0]:
            BOE.append(True)
            tabs[0] = tabs[0] + 1
        elif linea[0] == len(code) - 1 and line.replace("\t", "") == one_tab[2]:
            BOE.clear()
            tabs[0] = tabs[0] - 1
        else:
            Error.append(1)
            print("Error de codigo")
    else:
        Error.append(1)
        print("Error de codigo")
    return


def lectura_instrucciones(
        line: str):  # retorna un numero o una lista segun la instrucción que se le de. (es una lista si es una nueva instruccion definida)
    if Ftab():
        line = line.replace("\t", "")
        if line[
            -1] == ";":  # or line == "turnoff" or code[linea[0]+1].count("\t")== #code[linea[0]+1].replace("\t","") == "END" or code[linea[0]+1].replace("\t","") == "END;":
            line = line.replace(";", "")
            resultado = instrucciones[line]
            return resultado

        if line == "turnoff" or code[linea[0] + 1].count("\t") == tabs[0] - 1:
            resultado = instrucciones[line]
            tabs[0] = tabs[0] - 1
            return resultado
    Error.append(1)
    print("Error de codigo")


def iterate_check():  # revisa si es un itrate y retorna el numero de veces que se itera
    x = code[linea[0]].replace("\t", "")
    if x[:8] == "ITERATE " and x[-6:] == " TIMES" and Ftab():
        a = x[8:-6]
        if a.isnumeric():
            num = int(a)
            return num
        else:
            print("error")
            Error.append(1)
    else:
        return False


def iterate(
        num):  # realiza la iteración retornando una lista de las instrucciones dentro segun el numero que se le haya especificado
    if num <= 1:
        print("error")
        Error.append(1)
        return
    elif num > 120:
        print("error")
        Error.append(1)
        return
    else:
        resultado = []
        linea[0] = linea[0] + 1
        w = linea[0]
        line = code[w]
        W = line
        t = tabs[0]
        for i in range(num):
            linea[0] = w
            line = W
            tabs[0] = t
            if line.replace("\t", "") == "BEGIN" and Ftab():
                f = len(BEGIN)
                BEGIN.append(1)
                tabs[0] = tabs[0] + 1

                while f < len(BEGIN):
                    linea[0] = linea[0] + 1
                    line = code[linea[0]]
                    if End():
                        i
                    elif not cond_if_check():
                        val = lectura_instrucciones(line)
                        resultado.append(val)
        return resultado


def End():  # revisa si es un en, si lo es retorna verdadero, retira un valor a la lista BEGIN
    if Ftab():
        line = code[linea[0]]
        line.replace("\t", "")
        if "END" in line:
            if line[-1] == ";":
                BEGIN.pop(-1)
                return True
            elif code[linea[0] + 1].count("\t") == tabs[0] - 1:
                BEGIN.pop(-1)
                tabs[0] = tabs[0] - 1
                return True
            else:
                print("error")
                Error.append(1)
                BEGIN.pop(-1)
                tabs[0] = tabs[0] - 1
                return
        return False


def accion(num: int):  # revisa que acción se esta ejecutando, y las agrega a una lista
    recorrido.append(num)
    if len(Error) > 0:
        return
    if num == 0:
        move()
        recorridoSN.append(num)
    elif num == 1:
        turnleft()
        recorridoSN.append(num)
    elif num == 2:
        pickbeeper()
        recorridoSN.append(num)
    elif num == 3:
        putbeeper()
        recorridoSN.append(num)
    elif str(type(num)) == "<class 'list'>":
        for i in num:
            accion(i)


def Cond(num):  # revisa que condición se esta haciendo, retorna true si la condicion se cumple
    if num == 1:
        condicion = not front_is_blocked()
    elif num == 2:
        condicion = front_is_blocked()
    elif num == 3:
        condicion = not left_is_blocked()
    elif num == 4:
        condicion = left_is_blocked()
    elif num == 5:
        condicion = not right_is_blocked()
    elif num == 6:
        condicion = right_is_blocked()
    elif num == 7:
        condicion = next_to_a_beeper()
    elif num == 8:
        condicion = not next_to_a_beeper()
    elif num == 9:
        condicion = facing[0] == 0
    elif num == 10:
        condicion = facing[0] != 0
    elif num == 11:
        condicion = facing[0] == 1
    elif num == 12:
        condicion = facing[0] != 1
    elif num == 13:
        condicion = facing[0] == 2
    elif num == 14:
        condicion = facing[0] != 2
    elif num == 15:
        condicion = facing[0] == 3
    elif num == 16:
        condicion = facing[0] != 3
    elif num == 17:
        condicion = nbeepers[0] > 0
    return condicion


def cond_if_check():  # revisa si es un if, si lo es, retorna un numero que es la condición segun un diccionario llamado condiciones
    x = code[linea[0]].replace("\t", "")
    if x[:3] == condiocionades[0][:3] and x[-5:] == condiocionades[0][-5:] and Ftab():
        a = x[3:-5]
        if a in condiciones:
            num = condiciones[a]
            return num
    else:
        return False


def condIf(
        num):  # si el valor retornado en Cond() es verdadero, entonces realiza las acciones dentro del if, si no, pasa a la linea despues del End
    condicion = Cond(num)
    linea[0] = linea[0] + 1
    line = code[linea[0]]
    if condicion and not len(false) > 0:
        if line.replace("\t", "") == "BEGIN" and Ftab():
            f = len(BEGIN)
            BEGIN.append(1)
            tabs[0] = tabs[0] + 1
            contador = 0

            while f < len(BEGIN):
                linea[0] = linea[0] + 1
                line = code[linea[0]]
                if End():
                    return
                elif not cond_if_check():
                    if not cond_while_check():
                        if not iterate_check():
                            val = lectura_instrucciones(line)
                            accion(val)
                            contador += 1
                        else:
                            ins = iterate_check()
                            val = iterate(ins)
                            accion(val)
                    else:
                        ins = cond_while_check()
                        condWhile(ins)
                else:
                    ins = cond_if_check()
                    condIf(ins)

    else:
        if line.replace("\t", "") == "BEGIN" and Ftab():
            f = len(BEGIN)
            BEGIN.append(1)
            tabs[0] = tabs[0] + 1
            contador = 0
            false.append(1)
            i
            while f < len(BEGIN):
                linea[0] = linea[0] + 1
                line = code[linea[0]]
                if End():
                    false.pop(-1)
                    return
                elif not cond_if_check():
                    if not cond_while_check():
                        if not iterate_check():
                            val = lectura_instrucciones(line)
                            contador += 1
                        else:
                            ins = iterate_check()
                            iterate(val)
                    else:
                        ins = cond_while_check()
                        condWhile(ins)
                else:
                    ins = cond_if_check()
                    condIf(ins)


def cond_while_check():  # revisa si es un while, si lo es, retorna un numero que es la condición segun un diccionario llamado condiciones
    x = code[linea[0]].replace("\t", "")
    if x[:6] == condiocionades[1][:6] and x[-3:] == condiocionades[1][-3:] and Ftab():
        # a = code[linea[0]][5:-5]
        a = x[6:-3]
        if a in condiciones:
            num = condiciones[a]
            return num
    else:
        return False


def condWhile(
        num):  # si la condición es verdadera se ejecuta lo de adentro, y al acabar vuelve al Begin del inicio del while
    condicion = Cond(num)
    linea[0] = linea[0] + 1
    w = linea[0]
    line = code[w]
    W = line
    t = tabs[0]
    contador = 0
    if not condicion or len(false) > 0:
        if line.replace("\t", "") == "BEGIN" and Ftab():
            f = len(BEGIN)
            BEGIN.append(1)
            tabs[0] = tabs[0] + 1
            contador = 0
            false.append(1)
            while f < len(BEGIN):
                linea[0] = linea[0] + 1
                line = code[linea[0]]
                if End():
                    false.pop(-1)
                    return
                elif not cond_if_check():
                    if not cond_while_check():
                        if not iterate_check():
                            val = lectura_instrucciones(line)
                            contador += 1
                        else:
                            ins = iterate_check()
                            val = iterate(ins)
                    else:
                        ins = cond_while_check()
                        condWhile(ins)
                else:
                    ins = cond_if_check()
                    condIf(ins)

    while (condicion and not len(false) > 0) or contador > 30 or len(Error) > 0:
        linea[0] = w
        line = W
        tabs[0] = t
        if line.replace("\t", "") == "BEGIN" and Ftab():
            f = len(BEGIN)
            BEGIN.append(1)
            tabs[0] = tabs[0] + 1
            contador += 1

            while f < len(BEGIN):
                linea[0] = linea[0] + 1
                line = code[linea[0]]

                if End():
                    i
                elif not cond_if_check():
                    if not cond_while_check():
                        if not iterate_check():
                            val = lectura_instrucciones(line)
                            accion(val)

                        else:
                            ins = iterate_check()
                            val = iterate(ins)
                            accion(val)
                    else:
                        ins = cond_while_check()
                        condWhile(ins)
                else:
                    ins = cond_if_check()
                    condIf(ins)

        condicion = Cond(num)
        if contador > 30:
            print("error")
            Error.append(1)
            return


def NewBeepr():  # agrega a una lista, la posición actual de cada beeper en cada paso
    coordenadas_bepers = []
    for y in range(len(mapa_no_enter)):  # este
        for x in range(len(mapa_no_enter[y])):
            if [x, y] in coordenadas_beepers:
                coordenadaBeeper = []
                coordenadaBeeper.append(x)
                coordenadaBeeper.append(y)
                coordenadas_bepers.append(coordenadaBeeper)
    s_coordenadas_beepers.append(coordenadas_bepers)


# =============================================================================
# variables
# =============================================================================
Nokarel = 0
nbeepers = [0]
coordenadaKarel = []
coordenadas_beepers = []
coordenadas_muros = []

facing = [0]
facin = [0]
"""
0=facing_north
1=facing_south
2=facing_east
3=facing_west
"""
coordenadaKarl = []
s_coordenadaKarel = []
coordenadas_beeprs = []
s_coordenadas_muros = []
s_coordenadas_beepers = []

Error = []
tabs = [0]
linea = [1]
BOP = []
NI = []
BOE = []
BEGIN = []
false = []
recorridoSN = []
recorrido = []
# =============================================================================
# diccionarios
# =============================================================================
no_tabs = {
    0: "BEGINNING-OF-PROGRAM",
    1: "END-OF-PROGRAM"
}

one_tab = {
    0: "BEGINNING-OF-EXECUTION",
    1: "DEFINE-NEW-INSTRUCTION @ AS",
    2: "END-OF-EXECUTION"
}
instrucciones = {
    "move": 0,
    "turnleft": 1,
    "pickbeeper": 2,
    "putbeeper": 3,
    "turnoff": 4
}

condiocionades = {
    0: "IF @ THEN",
    1: "WHILE @ DO"
}

condiciones = {
    "front-is-clear": 1,
    "front-is-blocked": 2,
    "left-is-clear": 3,
    "left-is-blocked": 4,
    "right-is-clear": 5,
    "right-is-blocked": 6,
    "next-to-a-beeper": 7,
    "not-next-to-a-beeper": 8,
    "facing-north": 9,
    "not-facing-north": 10,
    "facing-south": 11,
    "not-facing-south": 12,
    "facing-east": 13,
    "not-facing-east": 14,
    "facing-west": 15,
    "not-facing-west": 16,
    "beeper-in-bag": 17
}
# =============================================================================
# abrir archivos
# =============================================================================

code = escrituraCodigo()

mapa_txt = "mapa.txt"
mapa = open(mapa_txt, "r")
list_mapa = mapa.readlines()
mapa_no_enter = []
for i in list_mapa:
    mapa_no_enter.append(i.replace("\n", ""))
longitud_mapaX = len(mapa_no_enter[0])
longitud_mapaY = len(mapa_no_enter)
del list_mapa

beepers_txt = "NBeeper.txt"
beepers = open(beepers_txt, "r")
list_beeper = beepers.readline()
beepersK = list_beeper[0]

# =============================================================================
# revisar si hay error en los archivos
# =============================================================================

if longitud_mapaY > 25 or longitud_mapaX > 25:
    Error.append(1)
    print("Error, el mapa supera la cantidad maxima de casillas, revise que el mapa se como maximo 25x25")

try:
    int(beepersK)
except:
    print("no ingreso un numero valido en Nbeeper")
    Error.append(1)
if len(Error) == 0:
    beepersK = int(beepersK)
    if beepersK < 0:
        print("no ingreso un numero valido en Nbeeper")
        Error.append(1)
nbeepers[0] = beepersK

# =============================================================================
# Lecutura del mapa
# =============================================================================
"se encarga leer donde hay beepers, muros y donde esta karel. si no se cumple con los caracters salta error"

for y in range(len(mapa_no_enter)):  # este
    if len(mapa_no_enter[y]) != longitud_mapaX:
        print("error, el mapa no es consistente")
        Error.append(1)
    for x in range(len(mapa_no_enter[y])):
        if ord(mapa_no_enter[y][x]) in [60, 62, 94, 118]:
            coordenadaKarel.append(x)
            coordenadaKarel.append(y)
            coordenadaKarl.append(x)
            coordenadaKarl.append(y)

            # s_coordenadaKarel.append(x)
            # s_coordenadaKarel.append(y)
            Nokarel += 1

            if ord(mapa_no_enter[y][x]) == 60:
                facing_west = True
                facing[0] = 3
                facin[0] = 3
            if ord(mapa_no_enter[y][x]) == 62:
                facing_east = True
                facing[0] = 2
                facin[0] = 2
            if ord(mapa_no_enter[y][x]) == 94:
                facing_north = True
                facing[0] = 0
                facin[0] = 0
            if ord(mapa_no_enter[y][x]) == 118:
                facing_south = True
                facing[0] = 1
                facin[0] = 1

        elif ord(mapa_no_enter[y][x]) == 35:
            coordenadaMuro = []
            coordenadaMuro.append(x)
            coordenadaMuro.append(y)
            coordenadas_muros.append(coordenadaMuro)
            s_coordenadas_muros.append(coordenadaMuro)

        elif ord(mapa_no_enter[y][x]) == 42:
            coordenadaBeeper = []
            coordenadaBeeper.append(x)
            coordenadaBeeper.append(y)
            coordenadas_beepers.append(coordenadaBeeper)
            coordenadas_beeprs.append(coordenadaBeeper)

        elif ord(mapa_no_enter[y][x]) != 46:
            print("error en el mapa, usando caracteres no especificados")
            Error.append(1)

if Nokarel > 1 or Nokarel == 0:
    print("error en el mapa, revise el numero de karels colocados en el mapa")
    Error.append(1)
# =============================================================================
# variables para la ejecución en pygame
# =============================================================================

x = coordenadaKarl[0]
y = coordenadaKarl[1]
facin = facing[0]
s_coordenadaKarel.append([x, y, facin])
s_coordenadas_beepers.append(coordenadas_beeprs)

# =============================================================================
# main
# =============================================================================


if len(Error) == 0:
    lecturaCodigo(code)
while len(Error) == 0 and not len(BOP) == 0:
    num = lecturaCodigo(code)
    accion(num)
    linea[0] = linea[0] + 1
