# =============================================================================
# se muestra la ejecucion del codigo
# =============================================================================


import pygame, lecturamapas
import colorsandtext as c
from funciones import *


def main():
    
    pygame.init()
    
    surface_sz = 600   
    surface = pygame.display.set_mode([surface_sz,surface_sz])    
    surface.fill(c.white) 
    
    running = True # variable para cerrar o mantener la ejecucion
    
    # Dibuja los puntos  
    for dots_lines in range(25):
        for d_dots in range(0,len(dots[0])):
            pygame.draw.circle(surface, c.black, dots[dots_lines][d_dots],1)
               
    # Dibuja Karel
    pygame.draw.polygon(surface, c.blue, karel[0])
    
    
    # Coloca Beeper
    for b_beeper in lecturamapas.s_coordenadas_beepers[0]:
        pygame.draw.circle(surface, c.red, dots[b_beeper[0]][b_beeper[1]], 4)
        
    # Coloca Muros
    for s_squares in lecturamapas.s_coordenadas_muros:
        surface.fill(c.black, squares[s_squares[0]][s_squares[1]])
    
    pygame.display.flip()
    
    try:
        x = 0
        for i in lecturamapas.recorridoSN: # itera sobre una lista en donde se definen todas las instrucciones a realizar
            pygame.time.wait(250)

            if i == 0:       # Visualizacion de la instruccion move
                surface.fill(c.white, squares[lecturamapas.s_coordenadaKarel[x][0]][lecturamapas.s_coordenadaKarel[x][1]]) #dibuja un cuadro blanco sobre la posicion de karel
                pygame.draw.circle(surface, c.black, dots[lecturamapas.s_coordenadaKarel[x][0]][lecturamapas.s_coordenadaKarel[x][1]], 1) # dibuja el punto que esta en el cuadro
                pygame.draw.polygon(surface, c.blue, karel[x+1]) # dibuja la nueva posicion de karel
                for p_beepers in lecturamapas.s_coordenadas_beepers[x]:  # toma los beepers activos en el mapa y los dibuja
                    pygame.draw.circle(surface, c.red, dots[p_beepers[0]][p_beepers[1]], 4)  # toma los beepers activos en el mapa y los dibuja
                x += 1 #incremento de x para ir a la siguiente instruccion


            if i == 1:  # Visualizacion de la instruccion turnleft
                surface.fill(c.white, squares[lecturamapas.s_coordenadaKarel[x][0]][lecturamapas.s_coordenadaKarel[x][1]]) #dibuja un cuadro blanco sobre la posicion de karel
                pygame.draw.circle(surface, c.black, dots[lecturamapas.s_coordenadaKarel[x][0]][lecturamapas.s_coordenadaKarel[x][1]], 1)  # dibuja el punto que esta en el cuadro
                pygame.draw.polygon(surface, c.blue, karel[x+1]) # # dibuja la nueva posicion de karel
                for p_beepers in lecturamapas.s_coordenadas_beepers[x]:
                    pygame.draw.circle(surface, c.red, dots[p_beepers[0]][p_beepers[1]], 4)
                x += 1  #incremento de x para ir a la siguiente instruccion


            if i == 2: # Visualizacion de la instruccion pickbeeper
                for e_beepers in lecturamapas.s_coordenadas_beepers[x - 1]:   # toma los beepers activos en el mapa de la instruccion anterior
                    surface.fill(c.white, squares[e_beepers[0]][e_beepers[1]])  # dibuja un cuadro blanco sobre los beepers anteriores
                    pygame.draw.circle(surface, c.black, dots[e_beepers[0]][e_beepers[1]], 1)   # dibuja el punto que esta en el cuadro
                pygame.draw.polygon(surface, c.blue, karel[x+1]) # dibuja la posicion de karel
                for p_beepers in lecturamapas.s_coordenadas_beepers[x]:   # toma los beepers activos en el mapa y los dibuja
                    pygame.draw.circle(surface, c.red, dots[p_beepers[0]][p_beepers[1]], 4)
                x += 1   #incremento de x para ir a la siguiente instruccion


            if i == 3: # Visualizacion de la instruccion putbeeper
                for pp_beepers in lecturamapas.s_coordenadas_beepers[x]:  # toma los bepeers activos en el mapa y los dibuja
                    pygame.draw.circle(surface, c.red, dots[pp_beepers[0]][pp_beepers[1]], 4)
                x += 1  #incremento de x para ir a la siguiente instruccion


            pygame.display.flip()


    except: # en caso de que la ejecucion presenta algun error
        running = False  # la variable pasa a false y cierra el programa
        print("Hubo un error en la ejecucion") # figura en la consola que hubo un error

    while running:
        ev = pygame.event.poll()
        if ev.type == pygame.QUIT:
            running = False             
    
main()
