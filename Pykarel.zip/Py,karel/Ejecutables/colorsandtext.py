#=======================================================================================================================
#archivo con tuplas de colores y strings de texto para facilitar el uso
#=======================================================================================================================

white      = (255, 255, 255)
red        = (255, 0, 0)
green      = (0, 255, 0)
blue       = (0, 0, 255)
bluesoft   = (0, 115, 155)
black      = (0, 0, 0)
silver     = (152, 152, 152)
silversoft = (100, 110, 115)
blueblack  = (32, 34, 37)
bluedark   = (17, 66, 91)
blueclear  = (82, 129, 168)
purple     = (99, 57, 90)
botones    = (69, 69, 69)
redsoft    = (200, 40, 40)



tex1 = "¡Bienvenido a Py.Karel!                                                          Este programa te ayudará a visualizar la ejecución de intrucciones para Karel."
tex2 = "Para ello son necesarios 2 archivos. Uno es el código, que debe estar escrito de manera correcta y con las tabulaciones necesarias, y el otro es el mapa de Karel en formato ASCII.                                                                Ve a las instrucciones y una vez que hayas seguido todos los pasos presiona      'Iniciar'.                                                                       Para los mapas puedes usar una de las plantillas incluidas en la carpeta         plantillas.                                                                      Si necesitas iniciar a karel con beepers en la bolsa escribe el número entero de beepers en el archivo 'nbeepers' sin dejar espacios innecesarios"
tex3 = "-karel tiene que ser uno de los siguientes: menor que <, mayor que > asento circunflejo ^ (alt+94), o la letra v minuscula)"
tex4 = "Escribe las instrucciones de Karel:                                                -Sin espacios entre líneas                                                       -Con las tabulaciones indicadas                                                  -Sin dejar espacios innecesarios en cada línea                                   -Con la sintaxis correcta                                                        -Sin errores léxicos                                                             -No utilices 'IF' o 'WHILE' al definir una nueva instrucción                     -No utilices 'IF' o 'WHILE' dentro de un 'ITERATE'."
tex5 = "Llama el archivo 'Test.txt' y ponlo en la carpeta 'Ejecutables' de py.Karel.     (Una vez que lo ejecutes puedes agragar un numero al final del nombre y guardarloen la carpeta 'Codigos')"
tex10 = "Llama el archivo 'mapa.txt' y ponlo en la carpeta 'Ejecutables' de py.Karel.     (Una vez que lo ejecutes puedes agragar un numero al final del nombre y guardarloen la carpeta 'Mapas')"
tex6 = "¡Te explicaremos como utilizar py.karel!"
tex7 = "Interactúa con las instrucciones mediante este botón"
tex8 = "Convierte el mapa de Karel a formato ASCII. Para ello ten en cuenta:"
tex9 = "  -Los espacios vacios (en que Karel se mueve) tienen que ser puntos '.'           -Los muros tienen que ser numerales '#'                                          -Los beepers tienen que ser asterisco '*'                                        -Karel tiene que ser uno de los siguientes: menor que '<', mayor que '>',        acento circunflejo '^' (alt+94), o la letra 'v' minúscula, dependiendo de su     orientación incial."

